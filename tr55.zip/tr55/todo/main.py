from . import db
from .models import User
from .models import Todolist
from flask import Blueprint, render_template, redirect, url_for, request, flash, abort
from flask_login import current_user, login_required

main = Blueprint('main', __name__)


@main.route('/')
def index():
    return render_template('index.html')


@main.route('/profile')
@login_required
def profile():
    return render_template('profile.html', name=current_user.name)


@main.route("/all")
@login_required
def user_item():
    user = User.query.filter_by(email=current_user.email).first_or_404()
    items = user.items  # Workout.query.filter_by(author=user).order_by(Workout.date_posted.desc())
    return render_template('all_items.html', items=items, user=user)


@main.route("/new")
@login_required
def new_item():
    return render_template('create_item.html')


@main.route("/new", methods=['POST'])
@login_required
def new_item_post():
    item = request.form.get('item')
    comment = request.form.get('comment')
    print(items, comment)
    todoitem = Todolist(items=items, comment=comment, author=current_user)
    db.session.add(todoitem)
    db.session.commit()
    flash('Your item has been added!')
    return redirect(url_for('main.index'))


@main.route("/item/<int:item_id>/update", methods=['GET', 'POST'])
@login_required
def update_item(item_id):
    item = Todolist.query.get_or_404(item_id)
    if request.method == "POST":
        item.item = request.form['item']
        item.comment = request.form['comment']
        db.session.commit()
        flash('Your post has been updated!')
        return redirect(url_for('main.user_item'))

    return render_template('update_item.html', item=item)


@main.route("/item/<int:item_id>/delete", methods=['GET', 'POST'])
@login_required
def delete_item(item_id):
    item = Todolist.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    flash('Your post has been deleted!')
    return redirect(url_for('main.user_item'))
